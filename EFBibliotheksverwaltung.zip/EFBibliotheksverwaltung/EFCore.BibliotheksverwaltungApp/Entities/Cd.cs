﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bibliotheksverwaltung.Core.Entities
{
    public  class Cd
    {
    }
}
