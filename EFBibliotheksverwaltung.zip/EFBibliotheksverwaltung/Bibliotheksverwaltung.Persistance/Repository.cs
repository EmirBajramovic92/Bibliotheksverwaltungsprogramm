﻿using System;

namespace Bibliotheksverwaltung.Persistance
{
    public class Repository
    {
    }
}
